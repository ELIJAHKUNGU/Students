<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
<div class="container" style="padding:50px 50px;">
<div class="row well alert alert-success"><?php echo "<pre>";print_R($_POST);?></div>
</div>