<?php 
	/*Update credentials*/
	define('EMAIL', 'YOUR EMAIL ');
	define('PASS', 'PASSWORD');
 ?>